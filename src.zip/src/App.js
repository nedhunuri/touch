import logo from './logo.svg';
import './App.css';
import Dashboard from './Dashboard';
import { BrowserRouter, Routes,Route} from 'react-router-dom';
import Navbar from './Components/Navbar';
import SideBar from './Sidebar';
import Login from './Components/Login';



function App() {
  return (
    <>
    <BrowserRouter>
    <Routes>
          
       <Route path="/" element={<Login/>}/>
       <Route path="/admin/dashboard" element={<SideBar/>}/>
       
    </Routes>
    </BrowserRouter>




  
  </>
  );
}

export default App;
