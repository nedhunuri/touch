import { Avatar, Box, Card, CardContent, Grid, Typography } from '@mui/material';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import MoneyIcon from '@mui/icons-material/Money';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { dashBoard } from './Redux/action';
import { red } from '@mui/material/colors';




const Dashboard = (props) => {

    const dispatch = useDispatch();
    const boardData = useSelector(state => state?.dashBoard);
    console.log(boardData);

//  const requiredData=[]
//  const dashBoardData=  Object.keys(boardData).forEach((key) => {
//     requiredData.push({
//           name: key,
//           about: boardData[key]
//         });
//       });
// console.log(requiredData);

    useEffect(() => {
        dispatch(dashBoard("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImFkbWluIiwidXNlcmlkIjozMiwiaWF0IjoxNjYyOTc2NzUxfQ.Me8Xefj9INkf2bwguebEZVQgr0JyRafWk_Cxevm2vrU"))
    }, [])


    return (
        <>
            <Grid container spacing={{ xs: 2, md: 3 }} columns={{ xs: 4, sm: 8, md: 12 }}>
                <Grid  item xs={2} sm={4} md={2}>
                    <Card
                        sx={{ height: '100%' ,background: 'linear-gradient(to right bottom, #36EAEF, #6B0AC9)' }}
                        {...props}
                    >
                        <CardContent>
                            <Grid
                                container
                                spacing={3}
                                sx={{ justifyContent: 'space-between' }}
                            >
                                <Grid item >
                                    <Typography
                                        color="textDanger"
                                        gutterBottom
                                        variant="h5"
                                    >
                                        Total Active users:

                                    </Typography>
                                    <Typography
                                        color="textPrimary"
                                        variant="h4"
                                    >
                                        {boardData?.active_users_count}
                                    </Typography>
                                </Grid>

                            </Grid>

                        </CardContent>
                    </Card>
                </Grid>
                <Grid  item xs={2} sm={4} md={2}>
                    <Card
                        sx={{ height: '100%',bgcolor: 'red' }}
                        {...props}
                    >
                        <CardContent>
                            <Grid
                                container
                                spacing={3}
                                sx={{ justifyContent: 'space-between' }}
                            >
                                <Grid item >
                                    <Typography
                                        color="textSecondary"
                                        gutterBottom
                                        variant="h5"
                                    >
                                        Total No of Posts:

                                    </Typography>
                                    <Typography
                                        color="textPrimary"
                                        variant="h4"
                                    >
                                        {boardData?.post_count}
                                    </Typography>
                                </Grid>

                            </Grid>

                        </CardContent>
                    </Card>
                </Grid>
                <Grid item xs={2} sm={4} md={2}>
                    <Card
                        sx={{ height: '100%',bgcolor: 'yellow' }}
                        {...props}
                    >
                        <CardContent>
                            <Grid
                                container
                                spacing={3}
                                sx={{ justifyContent: 'space-between' }}
                            >
                                <Grid item  >
                                    <Typography
                                        color="textSecondary"
                                        gutterBottom
                                        variant="h5"
                                    >
                                        Total No of Reels:

                                    </Typography>
                                    <Typography
                                        color="textPrimary"
                                        variant="h4"
                                    >
                                        {boardData?.reels_count}
                                    </Typography>
                                </Grid>

                            </Grid>

                        </CardContent>
                    </Card>
                </Grid>
                <Grid  item xs={2} sm={4} md={2}>
                    <Card
                        sx={{ height: '100%' ,bgcolor: 'cyan'}}
                        {...props}
                    >
                        <CardContent>
                            <Grid
                                container
                                spacing={3}
                                sx={{ justifyContent: 'space-between' }}
                            >
                                <Grid item>
                                    <Typography
                                        color="textSecondary"
                                        gutterBottom
                                        variant="h5"
                                    >
                                        Total No of Stories:

                                    </Typography>
                                    <Typography
                                        color="textPrimary"
                                        variant="h4"
                                    >
                                        {boardData?.story_count}
                                    </Typography>
                                </Grid>

                            </Grid>

                        </CardContent>
                    </Card>
                </Grid>



                <Grid  item xs={2} sm={4} md={2}>
                    <Card
                        sx={{ height: '100%' ,bgcolor: 'pink' }}
                        {...props}
                    >
                        <CardContent>
                            <Grid
                                container
                                spacing={3}
                                sx={{ justifyContent: 'space-between' }}
                            >
                                <Grid item>
                                    <Typography
                                        color="textSecondary"
                                        gutterBottom
                                        variant="h5"
                                    >
                                        Total No of users:

                                    </Typography>
                                    <Typography
                                        color="textPrimary"
                                        variant="h4"
                                    >
                                        {boardData?.user_count
}
                                    </Typography>
                                </Grid>

                            </Grid>

                        </CardContent>
                    </Card>
                </Grid>
            </Grid>

        </>
    )
}
export default Dashboard;