const userInitialState={
   loginData:{},
    error:{},
    dashBoard:[]
 }
 export const reducer=(state=userInitialState,action)=>{
   switch(action.type){
    case "DASH_BOARD":
       return{
          ...state,
          dashBoard:action.payload
       }
       case "LOGINSUCCESS":
         return{
             ...state,
             loginData:action.payload,
             error:""
         }
     case "LOGINFAILURE":
         return{
             ...state,
             loginData:"",
             error:action.payload
         }
       default:
        return state;
  
 }
}